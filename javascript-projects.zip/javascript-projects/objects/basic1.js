const pessoa = {
    nome: 'Lucas', idade: 19, 'sonhos pessoais': [{}],
    falar() {
        return 'Olá, minhas caracteristicas são: '
    },
    mente: {
        tipo: 'INTP', meme: 'Doomer',
    }
}

pessoa["sonhos pessoais"][0] = { tipo: 'carreira', nome: 'programador' },
    pessoa["sonhos pessoais"][1] = { tipo: 'pessoal', nome: 'viajar' }



let changeIdade = obj => {
    obj.idade = 18
}

changeIdade(pessoa)

console.log(pessoa.idade)







