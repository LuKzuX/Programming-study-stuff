let exTurmas = [
  {
    disciplina: 'LPOO',
    turma: 't01',
    dias: ['ter', 'sex'],
    horario: '16:40'
  },
  {
    disciplina: 'TPI',
    turma: 't02',
    dias: ['qua', 'sex'],
    horario: '20:20'
  },
  {
    disciplina: 'LPL',
    turma: 't03',
    dias: ['seg', 'qua'],
    horario: '18:30'
  }
];

function map(f, obj){
  const newArray = []
  for (let i = 0; i < obj.length; i++) {
    newArray[i] = f(obj[i])
  }
  return newArray
}

function f(x){
  return x.disciplina
}

console.log(map(f, exTurmas))
