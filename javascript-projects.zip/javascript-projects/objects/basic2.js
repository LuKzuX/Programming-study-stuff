let aviao = {
    tripulacao: {
        capitao: {
            nome: 'Lucas',
            idade: 18
        },
        engenheiro: {
            nome: 'Maria',
            idade: 29
        },
        medico: {
            nome: 'Luci',
            idade: 23
        }
    }
}


for (nomes in aviao.tripulacao) {
    console.log(`${nomes}: ${aviao.tripulacao[nomes].nome}`)
}

let changeName = (obj) => {
    obj.tripulacao.capitao.nome = 'Nou'
}

changeName(aviao)

console.log(aviao)

