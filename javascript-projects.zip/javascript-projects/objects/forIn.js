let friends = {
    explorer: {
        name: 'Lily',
        age: 17,
        speakExplorer() {
            console.log("What's there?, let's discover it!")
        },
        birthdayExplorer() {
            this.age += 1
        }
    },
    brave: {
        name: 'Louis',
        age: 21,
        speakBrave() {
            console.log("Don't be afraid!, i handle that!")
        },
        birthdayBrave() {
            this.age += 1
        },
        situation: 'missed'
    },
    thinker: {
        name: 'Giulia',
        age: 19,
        speakThinker() {
            console.log("What are we? What is this world?... What is... everything?")
        },
        birthdayThinker() {
            this.age += 1
        },
        ideas: ['think', 'ask', 'discover', 'change']
    }
}

friends.explorer.speakExplorer()
friends.explorer.birthdayExplorer()

function deleteKey(obj) {
    delete obj.brave.situation
}

deleteKey(friends)

for (friendName in friends) {
    console.log(`${friendName}: ${friends[friendName].name}, Age: ${friends[friendName].age}`)
}

function changeArr(f, array) {
    const newArray = []
    for (let i = 0; i < array.length; i++) {
        if (f(array[i])) {
            newArray[i] = array[i]
        }
    }
    return newArray
}

function f(x) {
    return x[0] == 't'
}

console.log(changeArr(f, friends.thinker.ideas))