const generateObject = (name, age, height, weight, color) => {
    return {
        name,
        age,
        height,
        weight,
        color,
        say() {
            if(typeof this.name === 'string' && this.name.length > 0){
               return `My name is ${this.name}`
            }else{
               return `No names found`
            }
        }
    }
}

let person = generateObject('Heus', 18, 1.80, 70.00, 'white')
console.log(person)
console.log(person.say())


