let object = {
    name: 'Computer',
    SO: '',
    Processor: 'Intel I5',
    RAM: 4,
    get checkSystem(){
        if(this.SO == 'Windows'){
            return `Software ${this.SO} known`
        }else if(this.SO == 'Apple'){
            return `Software ${this.SO} known`
        }else{
            return `Software unknown`
        }
    },
    set checkSystem(value){
        if(typeof value === 'string' && value.length > 0){
            this.SO = value
        }else{
            console.log('Write a valid Name')
        }
    }
}

object.SO = 'Windows'

console.log(object.checkSystem)


