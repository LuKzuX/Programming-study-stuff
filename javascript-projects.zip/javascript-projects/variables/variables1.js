var a = 5;
var b = 10;
var c = 5 + 10;
console.log(c)

var x = 20
var y = x += 10;
console.log(x)

let person = {name:'Lucas', age:'18', city:'Sumaré'}
let identy = 'My name is ' + person.name + ' i have ' + person.age + ', and i live in ' + person.city

console.log(identy)

