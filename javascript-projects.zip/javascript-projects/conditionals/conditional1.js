function conditional1(grade1, grade2, grade3) {
    result = (grade1 + grade2 + grade3) / 3;
    if (result > 10 || result < 0) {
        console.log('Invalid result! The result must have to be between 0 and 10')
    }
    else if (result >= 6) {
        console.log('You are fine!')
    } else {
        console.log('You are fired!')
    }
    return 'Your result is: ' + result;
}

console.log(conditional1(5, 7, 2))



function switch1(personality) {
    switch (personality.toUpperCase()) {
        case 'INTP':
            console.log("You have your own world, that's amazing!")
            break;
        case 'INTJ':
            console.log('Tell me your plans, you certainly have a lot!')
            break;
        case 'ENTP':
            console.log('You have your crazy ideas, and you want to show it to the world!')
            break;
        case 'ENTJ':
            console.log('You have plans and you are extroverted, what a person!')
            break;
        default:
            console.log('insert your personality');
    }
    return 'Your personality type is: ' + personality;
}

console.log(switch1('intp'))
