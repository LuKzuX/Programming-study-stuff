function fibo(terms) {
    let a = 0, b = 1, result = b
    for (let i = 1; i <= terms; i++) {
        console.log(result)
        result = a + b
        a = b
        b = result
    }
}

fibo(8)