function fac(x){
    let result = 1
    while(x >= 1){
        result *= x
        x--
    }
    return result
}

console.log(fac(4))

function facRec(x){
    if(x <= 1){
        return x
    }else{
        return x * facRec(x - 1)
    }
}

console.log(facRec(5))