function sumNum(a, b){
    if (a > b) {
        return 0
    }else{
        return a + sumNum(a + 1, b)
    }
}

console.log(sumNum(1, 5))