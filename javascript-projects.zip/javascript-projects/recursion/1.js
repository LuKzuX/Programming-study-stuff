function printNum(x) {
    if (x >= 50) {
        return x
    }
    else {
        console.log(x)
        return printNum(x + 1)

    }
}

console.log(printNum(1))