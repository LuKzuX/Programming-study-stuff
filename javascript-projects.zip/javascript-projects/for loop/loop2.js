function ex1() {
    const a = []
    for (let arr = -2; arr <= 3; arr++) {
        a.push(arr)
    }

    for (let i = 0; i < a.length; i++) {
        if (a[i] < 0) {
            console.log(a[i])
        }
    }
}

ex1()

/// ex 2 incompleto pq eu não sei progrmar sou burro inutil sem futuro fracassad///
function ex2() {
    let chico = 1.50;
    let ze = 1.10;
    let anos = 0;
   while(ze < chico){
       chico+=0.02
       ze+=0.03;
       anos++
   }
   return anos;
}

console.log(ex2())



function ex3() {
   
}

ex3()