///calculator///

function calc(num) {
    for (let i = 0; i <= 10; i++) {
        console.log(num * i)
    }
}

console.log(calc(7))

///PIZZAS FATIAS///

function comerPizza(fatias) {
    let comidas = 0;
    while (fatias !== 0) {
        fatias--
        comidas++
        if (fatias >= 0) {
            console.log('Vc comeu ' + comidas + ' fatias, restam ' + fatias + ' fatias')
        }
    }
}

comerPizza(10)

///ADICIONAR 1 ALUNO E REMOVER 1 DE CAPACIDADE ENQUANTO A CAPACIDADE FOR DIFERENTE DE 0, PARAR A REPETIÇÃO QUANDO A CAPACIDADE FOR MENOR QUE 0///

function salaDeAula(capacidade) {
    let alunos = 0;
    while (capacidade >= 0) {
        console.log('Há ' + alunos + ' alunos na sala, e restam ' + capacidade + ' lugares disponíveis')
        capacidade--
        alunos++
    }
}

salaDeAula(10)
///MESMA FUNÇÃO, PORÉM USANDO "FOR"///

function salaDeAula2(capacidade) {
    let alunos = 0
    for (capacidade; capacidade >= 0; capacidade--, alunos++) {
        console.log('Há ' + alunos + ' alunos na sala, e restam ' + capacidade + ' lugares disponíveis')
    }
}

salaDeAula2(10)







