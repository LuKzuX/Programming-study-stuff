///lendo os valores de 2 arrays e informando os assentos disponiveis e ocupados (incompleto)///

const assents = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
const choosen = [2, 5, 8]

const free = []

for (let i = 0; i < assents.length; i++) {
    for (let j = 0; j < choosen.length; j++) {
        if (assents[i] !== choosen[j]) {
            free.push(assents[i])
        }
    }
}

console.log('Assents free: ' + free)
console.log('Assents occuped: ' + choosen.join())


///LISTA COM MENSAGEM///

const favGames = ['Minecraft', 'Terraria', 'GTA V', 'Defiance', 'GranTurismo', 'Apex Legends']

function favGamesList() {
    for (let i = 0; i < favGames.length; i++){
    console.log('My favorite game is: ' + favGames[i])
    }
}

favGamesList();






