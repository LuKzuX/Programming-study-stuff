let ladoQuadrado = [5, 3, 8, 9]
let raioCirculos = [6, 2, 9, 6]

function calc(array, f) {
    let newArray = []
    for (let i = 0; i < array.length; i++) {
        newArray.push(f(array[i]))
    }
    return newArray
}

function perimeterQuadrado(x) {
    return x + x + x + x
}

function areaQuadrado(x) {
    return x * x
}

function areaCirculo(x) {
    return (Math.PI) * x * x
}

console.log(calc(ladoQuadrado, perimeterQuadrado))
console.log(calc(ladoQuadrado, areaQuadrado))

console.log(calc(raioCirculos, areaCirculo))