function reduce(f, array) {
    let resultado = 0
    for (let i = 0; i < array.length; i++) {
     resultado = f(resultado, array[i])
    }
    return resultado
}

function f (accumulator, element){
    return accumulator + element
}

const array = [4, 6, 2, 7]

let result = reduce(f, array)
console.log(result)

