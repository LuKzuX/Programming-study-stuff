const array = [1, 2, 3, 4, 5]

function changeNum(x) {
    console.log('number ' + (x + 3))
}

array.forEach(changeNum)

///////////////////////////////////////

function each(f, a) {
    for (let i = 0; i < a.length; i++) {
        f(a[i])
    }
}

const array2 = [1, 2, 3, 4]


const f = function (x) {
    console.log(x * x)
}

let result = each(f, array2)
result