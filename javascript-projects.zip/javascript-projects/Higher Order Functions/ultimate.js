function reduce(f, array) {
    let resultado = 0
    for (let i = 0; i < array.length; i++) {
        resultado = f(resultado, array[i])  
        console.log(resultado)
    }
    return resultado 
}

function createRandomArray(length) {  
    const array = []
    while (array.length < length) {
        let r = Math.floor(Math.random() * 11)
        array.push(r)
    }
    console.log(array)
    return array
}

function f(accumulator, actualItem) {
    return accumulator + actualItem
}

let result = reduce(f, createRandomArray(5))
console.log(result)
