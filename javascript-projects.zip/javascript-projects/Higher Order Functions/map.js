const numbers = [1, 2, 3, 4, 5]

const bigNumbers = numbers.map(function (number) {
    return number * 10
})

console.log(numbers)
console.log(bigNumbers)

////////////////////////

function map(f, array) {
    const bigNumbers = []
    for (let i = 0; i < array.length; i++) {
        bigNumbers[i] = f(array[i])
    }
    return bigNumbers
}

function array(length, i) {
    const array = []
    while (array.length < length) {
        array.push(i)
        i += i
    }
    console.log(array)
    return array
}


function bigNumbers2(x) {
    return x * 10
}

let result = map(bigNumbers2, array(5, 20))
console.log(result)