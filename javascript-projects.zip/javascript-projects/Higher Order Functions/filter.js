const array = ['Lucas', 'Pedro', 'Maria', 'Matheus']

const filtered = array.filter((n) => n[0] == 'M')

console.log(filtered)

/////////////////////

function filter(f, array) {
    const smallNumbers = []
    for (let i = 0; i < array.length; i++) {
        if (f(array[i])) {
            smallNumbers.push(array[i])
        }
    }
    return smallNumbers
}

const numbers = [4, 6, 2, 4, 7, 2, 4, 1, 7, 3]

function f(x) {
    return x < 5
}

let result = filter(f, numbers)
console.log(result)