function showNumber(number){
    console.log(number)
}

function newNumbers(n1, n2, f){
    let square = n1 * n2
    f(square)
}

newNumbers(5, 5, showNumber)

