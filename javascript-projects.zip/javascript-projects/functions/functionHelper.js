function convertToFareheint(celsius) {
    return celsius * (9 / 5);
}

function convertToFareheint2(celsius) {
    return convertToFareheint(celsius) + 32;
}

console.log(convertToFareheint2(30) + ' F')

///função pra calcular os segundos///
function convertToMinutes(hours) {
    return hours * 60;
}

function convertToSeconds(hours) {
    return convertToMinutes(hours) * 60;
}

console.log(convertToSeconds(1) + ' seconds') 

///Fazendo o mesmo, porém sem uma função ajudante///

function convertToFareheintNoHelper(celsius) {
    let conversion = (celsius * (9 / 5)) + 32;
    return conversion;
}

console.log(convertToFareheintNoHelper(30) + ' F')

function convertToSecondsNoHelper() {
    let hours = 1;
    return (hours * 60) * 60;
}

console.log(convertToSecondsNoHelper() + ' seconds');