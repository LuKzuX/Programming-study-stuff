const happyDay = function(day){
    if(day == 'Friday' || day == 'friday'){
        console.log('Today is the happy day, lets enjoy it!')
    }else{
        console.log('Not happy day today :(')
    }
    return day;
}

console.log(happyDay('friday'))