function countDown(number) {
    console.log(number)
    if (number > 0) {
        countDown(number - 1)
    }
}

/////////////////

function factorial(x) {
    if (x == 0) {
        return 1
    }
    else {
        console.log(x)
        return x * factorial(x - 1)
    }
}

console.log(factorial(5))

function sum(arr, initial = 0) {
    if (arr.length === 0) {
        return initial;
    }
    return sum(arr.slice(1), initial + arr[0]);
}

console.log(`${sum([1, 2, 3])}`);




