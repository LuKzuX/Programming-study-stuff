function convertToMph(kilometers) {
    let converter = 1.6
    return kilometers / converter;
}

console.log(convertToMph(400) + ' Mph')

///FAZENDO A NESMA FUNÇÃO, PORÉM DE OUTRA FORMA///

function convertToMph2(kilometers, converter){
    return kilometers / converter;
}

console.log(convertToMph2(220, 1.6) + ' Mph')

///FAZENDO A FUNÇÃO SEM PARAMETROS///

function convertToMph3(){
    let kilometers = 400;
    let converter = 1.6;
    let result = kilometers / converter;
    return result;
}

console.log(convertToMph3() + ' Mph');