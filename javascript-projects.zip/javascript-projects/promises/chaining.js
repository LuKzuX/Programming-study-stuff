const pessoa = {
    nome: 'Lucas',
    idade: 18,
    sexo: 'Masculino'
}

function checkObj(obj) {
    if (obj.nome && obj.idade && obj.sexo) {
        return true
    }
}

const promise = new Promise((resolve, reject) => {
    setTimeout(() => {
        console.log('checando objeto...')
        setTimeout(() => {
            if (checkObj(pessoa)) {
                resolve(pessoa)
            } else {
                reject('Dados faltando!')
            }
        }, 2000);

    }, 500);
})


promise
    .then((obj) => {
        console.log(obj.nome)
        return obj
    })
    .then((obj) => {
        console.log(obj.idade)
        return obj
    })
    .then((obj) => {
        console.log(obj.sexo)
        return obj
    })
    .catch((error) => {
        console.log(error)
    })

