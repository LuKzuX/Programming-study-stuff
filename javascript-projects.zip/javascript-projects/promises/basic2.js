const array = [3, 8, 8, 10]

function calc() {
    let media = 0
    for (let i = 0; i < array.length; i++) {
        media += array[i]
    }
    return media / array.length
}

const prom = new Promise((resolve, reject) => {
    setTimeout(() => {
        if (calc() >= 6) {
            resolve('Aprovado')
        } else {
            reject('Reprovado')
        }
    }, 1000);
})

const handleSuccess = (resolvedValue) => {
    console.log(resolvedValue);
};

const handleFailure = (rejectionReason) => {
    console.log(rejectionReason);
};

prom.then(handleSuccess, handleFailure);






