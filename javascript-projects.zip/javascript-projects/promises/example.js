const usersIds = new Promise((resolve) => {
    resolve([1, 2, 3, 4])
})

function usersInfo(id) {
    return new Promise((resolve) => {
        resolve({ id, nome: 'John Doe' })
    })
}

usersIds
    .then(ids => usersInfo(ids[1]))
    .then(user => console.log(user))