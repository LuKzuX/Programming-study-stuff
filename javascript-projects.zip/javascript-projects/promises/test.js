const prom = new Promise((reject) =>{
    reject('ouch')
})

prom
.catch((msg) =>{
    console.log(msg)
    return msg
})
