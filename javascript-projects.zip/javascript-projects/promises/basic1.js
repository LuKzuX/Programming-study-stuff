const inventory = {
    sunglasses: 100,
    pants: 1088,
    bags: 1344
};

const myExecutor = new Promise((resolve, reject) => {
    console.log('checking inventory...')
    setTimeout(() => {
        if (inventory.sunglasses > 0) {
            resolve('Sunglasses order processed.')
        } else {
            reject('That item is sold out.')

        }
    }, 2000);
})

myExecutor
.then((value) =>{
    console.log(value)
})
.catch(error => {
    console.log(error)
})
.finally(() =>{
    console.log('Process done!')
})


