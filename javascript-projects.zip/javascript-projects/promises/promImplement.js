class Promisee {
    constructor(executorFunction) {
        executorFunction(
            function resolve(params) {
                console.log(params)
            }, function reject(params) {
                console.log(params)
            })
    }
}

let item = 'something'

const prom = new Promisee((resolve, reject) => {
    setTimeout(() => {
        if (item) {
            resolve('existe')
        } else {
            reject('nao existe')
        }
    }, 2000);
})

prom
