const dogImg = document.querySelector('[data-js = "dog-img"]')

const validadeHTTPStatus = dogData => {
    if (!dogData.ok) {
        throw new Error(`HTTP error, status ${dogData.status}`)
    }
    return dogData.json()
}

const setDogImage = ({ message: url }) => {
    dogImg.setAttribute('src', url)
    console.log(url)
}

const handleError = error => {
    console.log(error.message)
}

fetch('https://dog.ceo/api/breeds/image/random')
    .then(validadeHTTPStatus)
    .then(setDogImage)
    .catch(handleError)

