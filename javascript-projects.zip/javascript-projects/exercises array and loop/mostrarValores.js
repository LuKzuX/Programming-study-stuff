const array = []

function mostrarValores() {
    while (array.length < 10) {
        var r = Math.floor(Math.random() * 202) - 101
        array.push(r)
    }
    let i = 0
    let media = 0
    let neg = 0
    let pos = 0

    while (i < array.length) {
        console.log(array[i])
        media += array[i] / array.length
        if (array[i] < 0) {
            neg++
        } else {
            pos++
        }
        i++
    }
    console.log('Número de números negativos: ' + neg)
    console.log('Número de números positivos: ' + pos)
    console.log('Percentual de números negativos: ' + neg * 10 + '%')
    console.log('Percentual de números positivos: ' + pos * 10 + '%')
    console.log('Média aritmética: ' + media)
}

mostrarValores()