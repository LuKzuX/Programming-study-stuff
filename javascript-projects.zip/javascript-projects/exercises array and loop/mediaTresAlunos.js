const aluno1 = [5, 6, 7]
const aluno2 = [2, 7, 3]
const aluno3 = [8, 6, 7]

let media1 = 0
let media2 = 0
let media3 = 0

let maior, menor

function mediaTresAlunos() {
    for (let a1 = 0; a1 < aluno1.length; a1++) {
        media1 += aluno1[a1] / aluno1.length
    }
    if (maior == undefined) {
        maior = media1
        menor = media1
    }

    for (let a2 = 0; a2 < aluno2.length; a2++) {
        media2 += aluno2[a2] / aluno2.length
    }
    if (media2 > maior) {
        maior = media2
    }
    if (media2 < menor) {
        menor = media2
    }

    for (let a3 = 0; a3 < aluno3.length; a3++) {
        media3 += aluno3[a3] / aluno3.length
    }
    if (media3 > maior) {
        maior = media3
    }
    if (media3 < menor) {
        menor = media3
    }

    console.log('Primeira nota: ' + media1)
    console.log('Primeira nota: ' + media2)
    console.log('Primeira nota: ' + media3)
    console.log('Maior nota: ' + maior)
    console.log('Menor nota: ' + menor)
}


mediaTresAlunos()