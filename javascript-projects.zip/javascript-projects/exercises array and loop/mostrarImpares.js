function mostrarImpares(){
    for(let i = 100; i <= 200; i++){
        if(i % 2 !== 0){
            console.log(i)
        }
    }
}

mostrarImpares()