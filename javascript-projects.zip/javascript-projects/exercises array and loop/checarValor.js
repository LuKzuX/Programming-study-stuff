function letArray (input){
    if(toString.call(input) === "[object Array]"){
    console.log('is array')
    return true
    }else{
        console.log('isnt array')
        return false
    }
}

letArray(8)