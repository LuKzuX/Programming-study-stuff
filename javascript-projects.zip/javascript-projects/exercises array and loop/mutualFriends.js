function mutualFriends(){
    const myFriends = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    const theirFriends = [2, 2, 2]
    const mutualFriends = []

    for(let i = 0; i < myFriends.length; i++){
        for(let j = 0; j < theirFriends.length; j++){
            if(myFriends[i] == theirFriends[j]){
                mutualFriends.push(myFriends[i])
            }
        }
    }
    console.log(mutualFriends)
}

mutualFriends()