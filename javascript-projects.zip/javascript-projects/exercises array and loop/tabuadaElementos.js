const array = []

function tabuadaValores() {
let mult = 0
    for (let i = 1; i < 11; i++) {
        array.push(i)
    }
  for(let j = 0; j < array.length; j++){
      for(let x = 1; x < 11; x++){
          mult = array[j] * x
          console.log(array[j] + ' x ' + x + ' = ' + mult)
      }
   }
}


tabuadaValores()