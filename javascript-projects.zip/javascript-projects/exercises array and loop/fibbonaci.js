function fibbonaci(numberOfTerms){
    let i = 0
    let fib = 0
    while(i <= numberOfTerms){
        console.log(i)   
        i++
         
    } 
}

fibbonaci(6)