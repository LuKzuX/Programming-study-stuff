const sorteio = []
const escolhidas = [2, 2, 2]
const iguais = []

let soma = 0

function bingo() {
    while (sorteio.length < 11) {
        let r = Math.floor(Math.random() * 11)
        sorteio.push(r)
    }
    for (let i = 0; i < sorteio.length; i++) {
        console.log(sorteio[i])
        soma += sorteio[i]
        for (let x = 0; x < escolhidas.length; x++) {
            if (sorteio[i] == escolhidas[x]) {
                iguais.push(sorteio[i])
            }
        }
    }
    console.log('soma: ' + soma)
    console.log('iguais: ' + iguais)

}

bingo()