function checarPosicaoMin(array, n) { 
    if(n == null){
        return console.log(array[0])
    }
       return console.log(array.slice(0, n))
}

checarPosicaoMin([2, 3, 4])

function checarPosicaoMax(array, n){
    if(n == null){
        return console.log(array[array.length - 1])
    }

    return console.log(array.slice(array.length - n))
}

checarPosicaoMax([1, 2, 3])
