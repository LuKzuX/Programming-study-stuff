let inicio = 6
let final = 3
let numerando = 9
for(let i = inicio; i >= final; i--){
    let mult = numerando * i
    console.log(numerando + 'x' + i + '=' + mult)
}

