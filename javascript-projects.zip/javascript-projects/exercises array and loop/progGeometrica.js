function geometrica(){
    let razao = 2
    for(a1 = 1; a1 <= 128; a1 *= razao){
        console.log(a1)
    }
}

geometrica()