const alturas = []

function maiorMenorAltura() {
    while (alturas.length < 16) {
        let r = Math.floor(Math.random() * 101)
        alturas.push(r)
    }
    let i = 0
    let maior;
    let menor;
    while (i < alturas.length) {
        if (maior == undefined) {
            maior = alturas[i]
            menor = alturas[i]
        }
        console.log(alturas[i])
        if (alturas[i] > maior) {
            maior = alturas[i]
        } if (alturas[i] < menor) {
            menor = alturas[i]
        }
        i++
    }
    console.log('Altura maior:' + maior)
    console.log('Altura menor:' + menor)
}

maiorMenorAltura()