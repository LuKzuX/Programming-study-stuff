const array = []

function mostrarValores() {
    while (array.length < 10) {
        var r = Math.floor(Math.random() * 101)
        array.push(r)
    }
    let i = 0
    let zero25 = 0
    let vinteSeis50 = 0
    let cinquentaUm75 = 0
    let setentaSeis100 = 0
    while (i < array.length) {
        if (array[i] >= 0 && array[i] < 26) {
            zero25++
           
            console.log('Numeros entre 0 e 25: ' + array[i])
        } else if (array[i] > 25 && array[i] < 51) {
            vinteSeis50++
            console.log('Numeros entre 26 e 50: ' + array[i])
        } else if (array[i] > 50 && array[i] < 76) {
            cinquentaUm75++
            console.log('Numeros entre 51 e 75: ' + array[i])
        } else if (array[i] > 75 && array[i] < 101) {
            setentaSeis100++
            console.log('Numeros entre 76 e 100: ' + array[i])
        }
        i++
    }
    console.log('Quantidade de numeros entre 0 e 25: ' + zero25)
    console.log('Quantidade de numeros entre 26 e 50: ' + vinteSeis50)
    console.log('Quantidade de numeros entre 51 e 75: ' + cinquentaUm75)
    console.log('Quantidade de numeros entre 76 e 100: ' + setentaSeis100)
}

mostrarValores()