function aritmetica(){
    let razao = 2
    for(a1 = 0; a1 <= 40; a1 += razao){
        console.log(a1)
    }
}

aritmetica()