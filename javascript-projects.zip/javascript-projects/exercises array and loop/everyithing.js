function createArray(length, mult) {
    const array = []
    i = 0
    let soma = 0
    while (array.length < length) {
        i++
        array.push(i)
    }
    for (let i = 0; i < array.length; i++) {
        multi = array[i] * mult
        soma += multi
        console.log(multi)
    }
    console.log('soma: ' + soma)
    console.log(array)
}

createArray(10, 1)

function objectt() {
    const object = { nome: '', sobrenome: '', idade: undefined, notas: [] }
    object.nome = 'Lucas'
    object.sobrenome = 'Galli'
    object.idade = 18
    object.notas = [6, 4, 8, 10]
    let mediaArray = 0
    for (let i = 0; i < object.notas.length; i++) {
        mediaArray += object.notas[i] / object.notas.length
    }
    console.log(object.nome, object.sobrenome + ', ' + object.idade + ' anos, ' + 'média: ' + mediaArray)
}
objectt()





