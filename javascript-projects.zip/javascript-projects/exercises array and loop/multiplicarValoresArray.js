const array = [5, 5, 5, 5]
let mult = 0
let re = 0
for(let i = 0; i < array.length; i++){
    mult += array[i] * 2
}
console.log(mult)