const numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

function arrayFunction(arr){
    return arr.push('11'), arr.pop();
}

console.log(numbers)


const myDreams = ['travel to another planet', 'Live in the future', 'change the world', 'be free']
myDreams[3] = 'Have unlimited power'

function actualDream(arr){
    return arr.slice(0, 1)
}
console.log(actualDream(myDreams))