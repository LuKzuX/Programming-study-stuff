///push: adiciona um novo valor ao final do array///
const list = ['arroz', 'feijao', 'leite']
list.push('ovos')
console.log(list)


///pop: remove o último valor do array///
const list2 = ['macarrão', 'salada', 'maracujá']
list2.pop()
console.log(list2)


///slice: seleciona partes do array///
const list3 = ['pão', 'trigo', 'óleo']
console.log(list3.slice(0, 1))


///shift: remove o primeiro valor do array///
const list4 = ['chocolate', 'laranja', 'sorvete']
list4.shift()
console.log(list4)


///unshift: adiciona um item ao inicio do array///
const list5 = ['açucar', 'alface', 'linguiça']
list5.unshift('peixe')
console.log(list5)


///indexOf: mostra a posição do elemento no array///
const list6 = ['folha', 'mago', 'lua']
console.log(list6.indexOf('mago'))
