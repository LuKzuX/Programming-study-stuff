const vetorInt = [1, 2, 3, 4, 5]
const vetorString = ['cachorro', 'gato', 'pombo']
const vetorDouble = [1.25, 2.10, 5.50]

const vetorGeral = vetorInt.concat(vetorString + " " + vetorDouble)

console.log(vetorGeral)