let aluno = 1
function createArray() {
    const pizza = []
    let n1 = parseFloat(document.getElementById('n1').value)
    let n2 = parseFloat(document.getElementById('n2').value)
    let n3 = parseFloat(document.getElementById('n3').value)
    let n4 = parseFloat(document.getElementById('n4').value)
    if(!verifica(n1) || !verifica(n2) || !verifica(n3) || !verifica(n4)){
        alert('INVALIDO')
        return;
    }
    pizza.push(n1, n2, n3, n4)
    let media = 0
    for (let i = 0; i < pizza.length; i++) {
        media += pizza[i] / pizza.length
    }
    document.getElementById('media').innerHTML += '<br> aluno' + aluno + ': ' + media 
    aluno++
}

function verifica(variable){
    if(variable < 0 || variable > 10 || isNaN(variable)){
        return false
    }else{
        return true
    }
}








