function mostrarArray() {
    const array = []
    let contador = 0
    let linhas = convertToNumber('linhas')
    let colunas = convertToNumber('colunas')

    for(let i = 0; i < linhas; i++){
        for(let c = 0; c < colunas; c++){
            contador++
            mult = linhas * colunas
            array.push('#')
        }
    }
    document.getElementById('array').innerHTML =  array + ' <br>Numero de termos: ' + contador
}

function convertToNumber(variable) {
    return parseFloat(document.getElementById(variable).value)
}



