let contador = 0
function add(){
    const pessoa = {id: undefined, nome: '', sobrenome: '', idade: undefined, origem: ''}
    
    pessoa.id = contador++
    pessoa.nome = valueOf('tNome')
    pessoa.sobrenome = valueOf('tSobrenome')
    pessoa.idade = toFloat('tIdade')
    pessoa.origem = valueOf('tOrigem') 
    console.log(pessoa)
    return false
}

function toFloat(variable){
    return parseFloat(document.getElementById(variable).value)
}

function valueOf(variable){
    return document.getElementById(variable).value
}


function del(){
    
}