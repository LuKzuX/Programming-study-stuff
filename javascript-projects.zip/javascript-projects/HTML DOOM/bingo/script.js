function bingo() {
    const escolhaArray = []
    const bingoArray = [22, 5, 37, 88, 10, 91, 1, 45, 65, 78]
    const iguaisArray = []
    let escolha1 = document.getElementById('num1').value
    let escolha2 = document.getElementById('num2').value
    let escolha3 = document.getElementById('num3').value
    let bingo = document.getElementById('bingo')
    let iguais = document.getElementById('iguais')
    let pontos = document.getElementById('pontos')


    escolhaArray.push(escolha1, escolha2, escolha3)


    for (let i = 0; i < bingoArray.length; i++) {
        for (let j = 0; j < escolhaArray.length; j++) {
            if (bingoArray[i] == escolhaArray[j]) {
                iguaisArray.push(bingoArray[i])
            }
        }
    }
    iguais.innerHTML = 'Numeros corretos: ' + iguaisArray
    bingo.innerHTML = 'Numeros do sorteio: ' + bingoArray
    pontos.innerHTML = 'pontos: ' + pontos

    }
   

