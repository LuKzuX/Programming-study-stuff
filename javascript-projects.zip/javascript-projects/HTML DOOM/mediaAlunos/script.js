let numAluno = 1
function calcularMedia() {
    const notas = []
    let nota1 = getFloat('nota1')
    let nota2 = getFloat('nota2')
    let nota3 = getFloat('nota3')
    let nota4 = getFloat('nota4')
    if (!isGradeValid(nota1) || !isGradeValid(nota2) || !isGradeValid(nota3) || !isGradeValid(nota4)) {
        alert('Nota invalida ou vazia')
        return;
    }
    let media = 0
    notas.push(nota1, nota2, nota3, nota4)
    for (let i = 0; i < notas.length; i++) {
        media += notas[i] / notas.length
    }
   
    let text = document.getElementById('medias').innerHTML
    document.getElementById('medias').innerHTML = `${text} <option> aluno ${numAluno}: ${media} </option>`
    numAluno++
}

function getFloat(elementId) {
    return parseFloat(document.getElementById(elementId).value)
}

function isGradeValid(nota) {
    if (nota < 0 || nota > 10 || isNaN(nota)) {
        return false
    } else {
        return true
    }
}



