class Honda {
    constructor(name, year, hp) {
        this._name = name
        this._year = year
        this._hp = hp
    }
    get name() {
        return this._name
    }
    get year() {
        return this._year
    }
    get hp() {
        return this._hp
    }
    engineUpgrade(level) {
        switch (level) {
            case 1:
                this._hp += 21
                break;
            case 2:
                this._hp += 45
                break;
            case 3:
                this._hp += 70
                break;
            case 4:
                this._hp += 100
                break;
            default:
                this._hp += 0

        }
    }
}

class Motorcycle extends Honda {
    constructor(name, year, hp, chest) {
        super(name, year, hp)
        this._chest = chest
    }
}

class Car extends Honda {
    constructor(name, year, hp, spoiler, pecas) {
        super(name, year, hp)
        this._spoiler = spoiler
        this._pecas = pecas
    }
    get pecas(){
        return this._pecas
    }

    addPecas(newPeca){
        this._pecas.push(newPeca)
    }
}

class Truck extends Honda {
    constructor(name, year, hp, wheel) {
        super(name, year, hp)
        this._wheel = wheel
    }
}

class Text extends Honda {
    constructor(name, year) {
        super(name, year)
    }
    get showText(){
       return `i have a ${this._name}, and it is of the year ${this._year}.`
    }
}

const Vespa = new Motorcycle('Vespa', 2001, 98, true)
Vespa.engineUpgrade(4)
console.log(Vespa)

const Civic = new Car('Honda Civic', 2006, 80, false, ['Motor', 'Retrovisor', 'Para-brisa'])
Civic.engineUpgrade(1)
Civic.addPecas('Escapamento')
console.log(Civic)



const Cab = new Truck('FH-800', 2010, 420, 12)
Cab.engineUpgrade(2)
console.log(Cab)

const texto = new Text(Civic.name, Civic.year)
console.log(texto.showText)





