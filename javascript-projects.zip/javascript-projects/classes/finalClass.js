class Animal {
    constructor(reino, filo) {
        this.reino = reino
        this.filo = filo
    }

}

class Cat extends Animal {
    constructor(nome, reino, filo, especie, caracteristicas) {
        super(reino, filo)
        this.nome = nome
        this.especie = especie
        this.caracteristicas = caracteristicas
    }

    speak() {
        console.log('Meoww')
    }

    addCarac(newCarac) {
        this.caracteristicas[this.caracteristicas.length] = newCarac
    }
}

const Romeu = new Cat('Romeu', 'Animal', 'Vertebrados', 'Felino', ['enjoado'])
Romeu.addCarac('esperto')
console.log(Romeu)