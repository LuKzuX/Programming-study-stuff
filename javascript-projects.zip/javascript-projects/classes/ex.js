class Shape{
    constructor(name, side, sideLength){
        this.name = name
        this.side = side
        this.sideLength = sideLength
    }
    calcPerimeter(){
        return this.side * this.sideLength + 'cm'
    }
    calcArea(){
        return this.sideLength * this.sideLength + 'cm'
    }
}

const square = new Shape('Square', 4, 12)
console.log(square.calcPerimeter())
console.log(square.calcArea())

