let i = 1
class Library {
    constructor(items = []) {
        this.items = items
    }
    addItem(newItem) {
        this.items[this.items.length] = '-' + i + ' ' + newItem
        i++
    }
}

const livros = new Library
livros.addItem('Lord of the rings')
livros.addItem('Confessions from an INTP')
livros.addItem('How to live in the world')
console.log(livros.items.sort())

const filtrarPorLetraInicial = livros.items.filter((x) => x[3] == 'L')


console.log(filtrarPorLetraInicial)



