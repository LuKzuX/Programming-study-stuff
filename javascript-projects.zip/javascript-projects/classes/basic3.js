class Imobiliaria {
    constructor(nome, endereco, interior) {
        this.nome = nome
        this.endereco = endereco
        this.interior = interior
    }
    
    addInterior(newItem){
        this.interior[this.interior.length] = newItem
    }
}

class Casa extends Imobiliaria {
    constructor(nome, endereco, preco, interior) {
        super(nome, endereco, interior)
        this.preco = preco
    }
}

const newCasa = new Casa('Casa Grande', 'Rua Vidro, nº465', 600.000, [])
newCasa.addInterior('o')
newCasa.addInterior(7)
console.log(newCasa.interior)