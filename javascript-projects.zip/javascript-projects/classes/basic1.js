class People {
    constructor(name, age){
        this.name = name;
        this.age = age;
    }
    incrementAge(){
        this.age++
    }
}

class Dog {
    constructor(name, age){
        this.name = name;
        this.age = age;
    }
    incrementAge(){
        this.age++
    }
}

const person = new People('Lucas', 18)
const dog = new Dog('Pretinha', 9)

person.incrementAge()
console.log(`${person.name} likes ${dog.name}`)