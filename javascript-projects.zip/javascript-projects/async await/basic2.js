const pessoa = {
    nome: 'John',
    idade: 30
}

function promise() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve(pessoa)
        }, 1000);
    })
}


async function await(){
    let value = await promise()
    console.log(value)
}

console.log(await())
