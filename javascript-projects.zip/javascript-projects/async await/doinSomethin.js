function buyRandomCar() {
    return new Promise((resolve, reject) => {
        const dealership = ['Lamborghini Aventador LP-700', 'Mazda 787B', 'Enzo Ferrari', 'Bugatti Veyron', 'Tesla Roadster']
        const randomChoose = Math.floor(Math.random() * 5)
        const myChoose = dealership[randomChoose] 
        setTimeout(() => {
            console.log(`I bought ${myChoose} because i liked it`)
            resolve(myChoose)
        }, 1000);
    })
}

async function getCar(){
    console.log(`Heading to the dealership to buy a car...`)
    let car = await buyRandomCar()
    console.log(`${car} is my new car!`)
}

getCar()

