async function withAsync(num) {
  if (num === 0) {
    return 'zero'
  } else {
    throw 'not zero'
  }
}

withAsync(1)
  .then((value) => {
    console.log(value)
  })
  .catch((error) => {
    console.log(error)
  })