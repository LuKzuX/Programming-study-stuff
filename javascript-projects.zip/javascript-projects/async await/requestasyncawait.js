const url = 'https://jsonplaceholder.typicode.com/users'

const getPosts = async () => {
    const response = await fetch(url)
    const finalresponse = await response.json()
    console.log(finalresponse)
}

getPosts()
