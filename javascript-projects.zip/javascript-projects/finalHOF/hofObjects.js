const movies = [
    { name: 'Avengers', release: 2012 },
    { name: 'Avatar', release: 2009 },
    { name: 'Edge of Tomorrow', release: 2014 },
    { name: 'Ready Player One', release: 2017 }
]

const moviesAfter2010 = movies.filter((movie) => movie.release >= 2010)

for(let i = 0; i < moviesAfter2010.length; i++){
    moviesAfter2010[i] = moviesAfter2010[i].release
}

function sumValues(array) {
    let sum = 0
    for (let i = 0; i < array.length; i++) {
        sum += array[i]
    }
    return sum
}

console.log(sumValues(moviesAfter2010))


const obj = {}

let property = 'nome'

obj['idade'] = 'test'
obj['sexo'] = 'o'

console.log(obj)
