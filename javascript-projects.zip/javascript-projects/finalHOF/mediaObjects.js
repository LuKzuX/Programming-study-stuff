const alunos = [
    { nome: 'Lucas', notas: [5, 7, 3, 10] },
    { nome: 'Luna', notas: [0, 8, 1, 4] },
    { nome: 'Diana', notas: [10, 10, 9, 10] }
]

function addToArray(array) {

}

