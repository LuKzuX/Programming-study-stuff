const movies = [
    { name: 'Avengers', release: 2012 },
    { name: 'Avatar', release: 2009 },
    { name: 'Edge of Tomorrow', release: 2014 },
    { name: 'Ready Player One', release: 2017 }
]

movies.forEach(function (x, index) {
    console.log('- ' + index + ' ' + x.name + ',', x.release)
})


function forEach(func, array){
    for(let i = 0; i < array.length; i++){
        func(array[i], i)
    }
}

function showList(x, index){
    console.log('- ' + index + ' ' + x.name + ', ' + x.release)
}

forEach(showList, movies)

